import os
import json
import pickle
from datetime import datetime
import numpy as np
import pandas as pd
import tensorflow as tf
import glob as glob
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.callbacks import EarlyStopping
from dotenv import load_dotenv
class Config:
    load_dotenv()

    COLUMNS_TO_USE = os.getenv('COLUMNS_TO_USE', '').split(',')
    COLUMNS_TO_USE_HIDS = os.getenv('COLUMNS_TO_USE_HIDS', '').split(',')

    RELATIVE_FROM = os.getenv('RELATIVE_FROM', '')
    RELATIVE_TO = os.getenv('RELATIVE_TO', '')

    TEST_SET_SIZE = int(os.getenv('TEST_SET_SIZE', 1000))
    EPOCHS = int(os.getenv('EPOCHS', 50))
    BATCH_SIZE = int(os.getenv('BATCH_SIZE', 8))

    HIDS_CONFIG = {
        "user": os.getenv('HIDS_USER'),
        "password": os.getenv('HIDS_PASSWORD'),
        "host": os.getenv('HIDS_HOST'),
        "port": int(os.getenv('HIDS_PORT', 10200)),
        "index": os.getenv('HIDS_INDEX')
    }

    NIDS_CONFIG = {
        "user": os.getenv('NIDS_USER'),
        "password": os.getenv('NIDS_PASSWORD'),
        "host": os.getenv('NIDS_HOST'),
        "port": int(os.getenv('NIDS_PORT', 9200)),
        "index": os.getenv('NIDS_INDEX')
    }

    TRAIN_RAW_DATA = "app/data/TRAIN_RAW_DATA.csv"
    TRAIN_DATA = "app/data/TRAIN_DATA.csv"

class DataProcessorNids:
    def __init__(self, config):
        self.config = config
        self.scaler = StandardScaler()

    def preprocess(self, df):
        df_processed = df.loc[:, self.config.COLUMNS_TO_USE]
        df_original = df_processed.copy()

        for column in self.config.COLUMNS_TO_USE:
            if column in ['source.port', 'destination.port']:
                df_processed[column] = pd.to_numeric(df_processed[column])
            df_processed[column] = df_processed[column].apply(lambda x: tuple(x) if isinstance(x, list) else x)
            df_processed[column] = pd.util.hash_pandas_object(df_processed[column], index=False, hash_key="95f9a5658c386e04")

        return df_processed, df_original

    def scale_data(self, data):
        return self.scaler.fit_transform(data)

    def inverse_scale(self, data):
        return self.scaler.inverse_transform(data)

class DataProcessorHids:
    def __init__(self, config):
        self.config = config
        self.scaler = StandardScaler()

    def preprocess(self, df):
        df_processed = df.loc[:, self.config.COLUMNS_TO_USE_HIDS]
        df_original = df_processed.copy()

        for column in self.config.COLUMNS_TO_USE_HIDS:
            df_processed[column] = df_processed[column].apply(lambda x: tuple(x) if isinstance(x, list) else x)
            df_processed[column] = pd.util.hash_pandas_object(df_processed[column], index=False, hash_key="95f9a5658c386e04")

        return df_processed, df_original

    def scale_data(self, data):
        return self.scaler.fit_transform(data)

    def inverse_scale(self, data):
        return self.scaler.inverse_transform(data)

class AutoencoderModel:
    def __init__(self, input_dim, dropout_rate=0.2):
        self.model = self.create_autoencoder(input_dim, dropout_rate)

    def create_autoencoder(self, input_dim, dropout_rate):
        input_layer = tf.keras.layers.Input(shape=(input_dim,))
        
        # Encoder
        encoded = tf.keras.layers.Dense(128, activation='relu')(input_layer)
        encoded = tf.keras.layers.Dropout(dropout_rate)(encoded)
        encoded = tf.keras.layers.Dense(64, activation='relu')(encoded)
        encoded = tf.keras.layers.Dropout(dropout_rate)(encoded)
        encoded = tf.keras.layers.Dense(32, activation='relu')(encoded)
        encoded = tf.keras.layers.Dropout(dropout_rate)(encoded)
        encoded = tf.keras.layers.Dense(16, activation='relu')(encoded)
        
        # Decoder
        decoded = tf.keras.layers.Dense(32, activation='relu')(encoded)
        decoded = tf.keras.layers.Dropout(dropout_rate)(decoded)
        decoded = tf.keras.layers.Dense(64, activation='relu')(decoded)
        decoded = tf.keras.layers.Dropout(dropout_rate)(decoded)
        decoded = tf.keras.layers.Dense(128, activation='relu')(decoded)
        decoded = tf.keras.layers.Dropout(dropout_rate)(decoded)
        decoded = tf.keras.layers.Dense(input_dim, activation='linear')(decoded)
        
        autoencoder = tf.keras.models.Model(input_layer, decoded)
        autoencoder.compile(optimizer='adam', loss='mean_squared_error', metrics=['accuracy'])
        
        return autoencoder

    def train(self, train_data, val_data, epochs, batch_size):
        early_stop = EarlyStopping(monitor='val_loss', patience=3, verbose=1)
        history = self.model.fit(
            train_data, train_data,
            epochs=epochs,
            batch_size=batch_size,
            validation_data=(val_data, val_data),
            verbose=1,
            callbacks=[early_stop]
        )
        return history

    def predict(self, data):
        return self.model.predict(data)

    def save(self, filepath):
        self.model.save(filepath)

    @classmethod
    def load(cls, filepath):
        model = tf.keras.models.load_model(filepath, compile=False)
        model.compile(optimizer='adam', loss='mean_squared_error', metrics=['accuracy'])
        instance = cls(model.input_shape[1])
        instance.model = model
        return instance

class AnomalyDetector:
    def __init__(self, model, threshold):
        self.model = model
        self.threshold = threshold

    def detect_anomalies(self, data):
        reconstructed = self.model.predict(data)
        mse = np.mean(np.power(data - reconstructed, 2), axis=1)
        return mse, mse > self.threshold

    def calculate_threshold(self, data, percentile=95):
        reconstructed = self.model.predict(data)
        mse = np.mean(np.power(data - reconstructed, 2), axis=1)
        return np.percentile(mse, percentile)

class FeatureImportanceHids:
    @staticmethod
    def calculate(model, data, feature_names):
        original_mse = np.mean(np.power(data - model.predict(data), 2), axis=0)
        importance = []
        
        for i in range(data.shape[1]):
            temp_data = data.copy()
            temp_data[:, i] = 0  # Zero out the i-th feature
            perturbed_mse = np.mean(np.power(temp_data - model.predict(temp_data), 2), axis=0)
            importance.append(np.mean(perturbed_mse - original_mse))
        
        feature_imp = np.array(importance)
        return pd.DataFrame({'feature': feature_names, 'importance': feature_imp}).sort_values('importance', ascending=False)
    
class FeatureImportanceNids:
    @staticmethod
    def calculate(model, data, feature_names):
        original_mse = np.mean(np.power(data - model.predict(data), 2), axis=0)
        importance = []
        
        for i in range(data.shape[1]):
            temp_data = data.copy()
            temp_data[:, i] = 0  # Zero out the i-th feature
            perturbed_mse = np.mean(np.power(temp_data - model.predict(temp_data), 2), axis=0)
            importance.append(np.mean(perturbed_mse - original_mse))
        
        feature_imp = np.array(importance)
        return pd.DataFrame({'feature': feature_names, 'importance': feature_imp}).sort_values('importance', ascending=False)

class ModelManagerNids:
    def __init__(self, base_folder='app/scripts/graph_strona/encoder'):
        self.base_folder = base_folder

    def create_date_folder(self):
        current_date = datetime.now().strftime('%Y-%m-%d %H:%M')
        date_folder = os.path.join(self.base_folder, current_date)
        os.makedirs(date_folder, exist_ok=True)
        return date_folder

    def save_model(self, model, scaler, threshold, feature_importance, folder):
        model.save(os.path.join(folder, 'autoencoder.h5'))
        with open(os.path.join(folder, 'scaler.pkl'), 'wb') as f:
            pickle.dump(scaler, f)
        with open(os.path.join(folder, 'threshold.json'), 'w') as f:
            json.dump({"threshold": threshold}, f)
        feature_importance.to_csv(os.path.join(folder, 'feature_importance.csv'), index=False)

    def load_latest_model(self):
        latest_folder = max(glob.glob(os.path.join(self.base_folder, '*')), key=os.path.getmtime)
        model = AutoencoderModel.load(os.path.join(latest_folder, 'autoencoder.h5'))
        with open(os.path.join(latest_folder, 'scaler.pkl'), 'rb') as f:
            scaler = pickle.load(f)
        with open(os.path.join(latest_folder, 'threshold.json'), 'r') as f:
            threshold = json.load(f)['threshold']
        return model, scaler, threshold

class ModelManagerHids:
    def __init__(self, base_folder='app/scripts/graph_strona/encoder_wazuh'):
        self.base_folder = base_folder

    def create_date_folder(self):
        current_date = datetime.now().strftime('%Y-%m-%d %H:%M')
        date_folder = os.path.join(self.base_folder, current_date)
        os.makedirs(date_folder, exist_ok=True)
        return date_folder

    def save_model(self, model, scaler, threshold, feature_importance, folder):
        model.save(os.path.join(folder, 'autoencoder.h5'))
        with open(os.path.join(folder, 'scaler.pkl'), 'wb') as f:
            pickle.dump(scaler, f)
        with open(os.path.join(folder, 'threshold.json'), 'w') as f:
            json.dump({"threshold": threshold}, f)
        feature_importance.to_csv(os.path.join(folder, 'feature_importance.csv'), index=False)

    def load_latest_model(self):
        latest_folder = max(glob.glob(os.path.join(self.base_folder, '*')), key=os.path.getmtime)
        print(latest_folder)
        model = AutoencoderModel.load(os.path.join(latest_folder, 'autoencoder.h5'))
        with open(os.path.join(latest_folder, 'scaler.pkl'), 'rb') as f:
            scaler = pickle.load(f)
        with open(os.path.join(latest_folder, 'threshold.json'), 'r') as f:
            threshold = json.load(f)['threshold']
        return model, scaler, threshold

class AutoencoderSystemNids:
    def __init__(self, config):
        self.config = config
        self.data_processor = DataProcessorNids(config)
        self.model_manager = ModelManagerNids()

    def save_data_versions(self, original_df, processed_df, folder_path):
        """
        Save both original and processed (hashed) versions of the data
        
        Args:
            original_df: Original DataFrame before processing
            processed_df: DataFrame after processing (hashed values)
            folder_path: Path to save the data files
        """
        # Save original data
        original_data_path = os.path.join(folder_path, 'input_data_original.csv')
        original_df.to_csv(original_data_path, index=False)
        
        # Save processed (hashed) data
        processed_data_path = os.path.join(folder_path, 'input_data_hashed.csv')
        processed_df.to_csv(processed_data_path, index=False)
        
        # Create a mapping file showing the relationship between original and hashed values
        mapping_data = []
        for column in original_df.columns:
            unique_mappings = dict(zip(original_df[column], processed_df[column]))
            mapping_data.append({
                'column': column,
                'mappings': unique_mappings
            })
        
        mapping_path = os.path.join(folder_path, 'hash_mappings.json')
        with open(mapping_path, 'w') as f:
            json.dump(mapping_data, f, indent=4, default=str)

    def train(self, df, settings=None):
        print("training")
        date_folder = self.model_manager.create_date_folder()
        
        if settings:
            self.config.COLUMNS_TO_USE_HIDS = settings['COLUMNS_TO_USE_HIDS']
            self.config.RELATIVE_FROM = settings['RELATIVE_FROM']
            self.config.RELATIVE_TO = settings['RELATIVE_TO']
            self.config.EPOCHS = settings['epochs']
            self.config.BATCH_SIZE = settings['batch_size']
        else:
            epochs = 50
            batch_size = 8

        # Get both processed and original data
        train_data, original_data = self.data_processor.preprocess(df)
        
        # Save both versions of the data
        self.save_data_versions(original_data, train_data, date_folder)
        
        train_data, val_data = train_test_split(train_data, test_size=0.2, random_state=42)

        train_data_scaled = self.data_processor.scale_data(train_data)
        val_data_scaled = self.data_processor.scale_data(val_data)

        model = AutoencoderModel(train_data_scaled.shape[1])
        history = model.train(train_data_scaled, val_data_scaled, epochs, batch_size)

        anomaly_detector = AnomalyDetector(model, 0)  # Temporary threshold
        threshold = anomaly_detector.calculate_threshold(val_data_scaled)
        anomaly_detector.threshold = threshold

        feature_importance = FeatureImportanceNids.calculate(model.model, val_data_scaled, self.config.COLUMNS_TO_USE)

        # Save training metadata
        training_metadata = {
            'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_shape': train_data.shape,
            'epochs': epochs,
            'batch_size': batch_size,
            'final_threshold': threshold,
            'columns_used': self.config.COLUMNS_TO_USE_HIDS
        }
        metadata_path = os.path.join(date_folder, 'training_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(training_metadata, f, indent=4)

        self.model_manager.save_model(model.model, self.data_processor.scaler, threshold, feature_importance, date_folder)

        return model, history, threshold

    def retrain(self, df, settings=None):
        print("retarining")
        try:
            model, scaler, threshold = self.model_manager.load_latest_model()
            self.data_processor.scaler = scaler
        except Exception as e:
            print(f"Error loading existing model: {e}")
            return self.train(df, settings)

        date_folder = self.model_manager.create_date_folder()

        if settings:
            self.config.COLUMNS_TO_USE_HIDS = settings['COLUMNS_TO_USE_HIDS']
            self.config.RELATIVE_FROM = settings['RELATIVE_FROM']
            self.config.RELATIVE_TO = settings['RELATIVE_TO']
            self.config.EPOCHS = settings['epochs']
            self.config.BATCH_SIZE = settings['batch_size']
        else:
            epochs = 50
            batch_size = 8

        # Get both processed and original data
        train_data, original_data = self.data_processor.preprocess(df)
        
        # Save both versions of the data
        self.save_data_versions(original_data, train_data, date_folder)
        
        train_data, val_data = train_test_split(train_data, test_size=0.2, random_state=42)

        train_data_scaled = self.data_processor.scale_data(train_data)
        val_data_scaled = self.data_processor.scale_data(val_data)

        history = model.train(train_data_scaled, val_data_scaled, epochs, batch_size)

        anomaly_detector = AnomalyDetector(model, 0)  # Temporary threshold
        threshold = anomaly_detector.calculate_threshold(val_data_scaled)
        anomaly_detector.threshold = threshold

        feature_importance = FeatureImportanceNids.calculate(model.model, val_data_scaled, self.config.COLUMNS_TO_USE)

        # Save retraining metadata
        retraining_metadata = {
            'retraining_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_shape': train_data.shape,
            'epochs': epochs,
            'batch_size': batch_size,
            'final_threshold': threshold,
            'columns_used': self.config.COLUMNS_TO_USE
        }
        metadata_path = os.path.join(date_folder, 'retraining_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(retraining_metadata, f, indent=4)

        self.model_manager.save_model(model.model, self.data_processor.scaler, threshold, feature_importance, date_folder)

        return model, history, threshold

class AutoencoderSystemHids:
    def __init__(self, config):
        self.config = config
        self.data_processor = DataProcessorHids(config)
        self.model_manager = ModelManagerHids()

    def save_data_versions(self, original_df, processed_df, folder_path):
        """
        Save both original and processed (hashed) versions of the data
        
        Args:
            original_df: Original DataFrame before processing
            processed_df: DataFrame after processing (hashed values)
            folder_path: Path to save the data files
        """
        # Save original data
        original_data_path = os.path.join(folder_path, 'input_data_original.csv')
        original_df.to_csv(original_data_path, index=False)
        
        # Save processed (hashed) data
        processed_data_path = os.path.join(folder_path, 'input_data_hashed.csv')
        processed_df.to_csv(processed_data_path, index=False)
        
        # Create a mapping file showing the relationship between original and hashed values
        mapping_data = []
        for column in original_df.columns:
            unique_mappings = dict(zip(original_df[column], processed_df[column]))
            mapping_data.append({
                'column': column,
                'mappings': unique_mappings
            })
        
        mapping_path = os.path.join(folder_path, 'hash_mappings.json')
        with open(mapping_path, 'w') as f:
            json.dump(mapping_data, f, indent=4, default=str)

    def train(self, df, settings=None):
        print("training in progress")
        date_folder = self.model_manager.create_date_folder()
        
        if settings:
            self.config.COLUMNS_TO_USE_HIDS = settings['COLUMNS_TO_USE_HIDS']
            self.config.RELATIVE_FROM = settings['RELATIVE_FROM']
            self.config.RELATIVE_TO = settings['RELATIVE_TO']
            self.config.EPOCHS = settings['epochs']
            self.config.BATCH_SIZE = settings['batch_size']
        else:
            epochs = 50
            batch_size = 8

        # Get both processed and original data
        train_data, original_data = self.data_processor.preprocess(df)
        
        # Save both versions of the data
        self.save_data_versions(original_data, train_data, date_folder)
        
        train_data, val_data = train_test_split(train_data, test_size=0.2, random_state=42)

        train_data_scaled = self.data_processor.scale_data(train_data)
        val_data_scaled = self.data_processor.scale_data(val_data)

        model = AutoencoderModel(train_data_scaled.shape[1])
        history = model.train(train_data_scaled, val_data_scaled, epochs, batch_size)

        anomaly_detector = AnomalyDetector(model, 0)  # Temporary threshold
        threshold = anomaly_detector.calculate_threshold(val_data_scaled)
        anomaly_detector.threshold = threshold

        feature_importance = FeatureImportanceHids.calculate(model.model, val_data_scaled, self.config.COLUMNS_TO_USE_HIDS)

        # Save training metadata
        training_metadata = {
            'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_shape': train_data.shape,
            'epochs': epochs,
            'batch_size': batch_size,
            'final_threshold': threshold,
            'columns_used': self.config.COLUMNS_TO_USE_HIDS
        }
        metadata_path = os.path.join(date_folder, 'training_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(training_metadata, f, indent=4)

        self.model_manager.save_model(model.model, self.data_processor.scaler, threshold, feature_importance, date_folder)

        return model, history, threshold

    def retrain(self, df, settings=None):
        print("retraining in progress")
        try:
            model, scaler, threshold = self.model_manager.load_latest_model()
            self.data_processor.scaler = scaler
            
        except Exception as e:
            print(f"Error loading existing model: {e}")
            return self.train(df, settings)

        date_folder = self.model_manager.create_date_folder()

        if settings:
            self.config.COLUMNS_TO_USE_HIDS = settings['COLUMNS_TO_USE_HIDS']
            self.config.RELATIVE_FROM = settings['RELATIVE_FROM']
            self.config.RELATIVE_TO = settings['RELATIVE_TO']
            self.config.EPOCHS = settings['epochs']
            self.config.BATCH_SIZE = settings['batch_size']
        else:
            epochs = 50
            batch_size = 8

        # Get both processed and original data
        train_data, original_data = self.data_processor.preprocess(df)
        
        # Save both versions of the data
        self.save_data_versions(original_data, train_data, date_folder)
        
        train_data, val_data = train_test_split(train_data, test_size=0.2, random_state=42)

        train_data_scaled = self.data_processor.scale_data(train_data)
        val_data_scaled = self.data_processor.scale_data(val_data)

        history = model.train(train_data_scaled, val_data_scaled, epochs, batch_size)

        anomaly_detector = AnomalyDetector(model, 0)  # Temporary threshold
        threshold = anomaly_detector.calculate_threshold(val_data_scaled)
        anomaly_detector.threshold = threshold

        feature_importance = FeatureImportanceHids.calculate(model.model, val_data_scaled, self.config.COLUMNS_TO_USE_HIDS)

        # Save retraining metadata
        retraining_metadata = {
            'retraining_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'data_shape': train_data.shape,
            'epochs': epochs,
            'batch_size': batch_size,
            'final_threshold': threshold,
            'columns_used': self.config.COLUMNS_TO_USE_HIDS
        }
        metadata_path = os.path.join(date_folder, 'retraining_metadata.json')
        with open(metadata_path, 'w') as f:
            json.dump(retraining_metadata, f, indent=4)

        self.model_manager.save_model(model.model, self.data_processor.scaler, threshold, feature_importance, date_folder)

        return model, history, threshold
