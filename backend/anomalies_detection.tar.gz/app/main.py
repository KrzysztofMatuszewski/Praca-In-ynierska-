from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Dict, Any, Union
import json 
import os
import pandas as pd
from datetime import datetime
import sys
from app.config import  functions
from app.config import Config
import requests
from threading import Lock
import redis
from opensearchpy import OpenSearch, helpers


from tensorflow import keras
import pickle
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.retrain.autoencoder_all import (
    AutoencoderSystemNids, AutoencoderSystemHids,
    ModelManagerNids, ModelManagerHids,
    DataProcessorNids, DataProcessorHids
)

app = FastAPI()

# Mount static files and templates
app.mount("/static", StaticFiles(directory="app/scripts/graph_strona/static"), name="static")
templates = Jinja2Templates(directory="app/scripts/graph_strona/templates")

nids_encoder_base_path = os.path.relpath("app/scripts/graph_strona/encoder")
hids_encoder_base_path = os.path.relpath("app/scripts/graph_strona/encoder_wazuh")

encoder_lock = Lock()

# Initialize the AutoencoderSystem
config = Config()

# nids_model = Model(nids_encoder_base_path)
autoencoder_system_nids = AutoencoderSystemNids(config)
data_processor_nids = DataProcessorNids(config)
model_manager_nids = ModelManagerNids()

autoencoder_system_hids = AutoencoderSystemHids(config)
data_processor_hids = DataProcessorHids(config)
model_manager_hids = ModelManagerHids()


class EncoderInitializer:
    def __init__(self, event_source):
        self.event_source = event_source
        self.scaler = None
        self.threshold = None
        self.autoencoder = None
        self.initialize()

    def initialize(self):
        try:
            # Determine the base path based on event source
            encoder_base_path = (
                hids_encoder_base_path if self.event_source == "hids" 
                else nids_encoder_base_path
            )

            # Find the latest folder
            latest_folder = get_latest_folder(encoder_base_path)
            print(f"Latest folder found: {latest_folder}")

            # Load scaler
            scaler_path = os.path.join(latest_folder, 'scaler.pkl')
            print(f"Loading scaler from: {scaler_path}")
            with open(scaler_path, 'rb') as f:
                self.scaler = pickle.load(f)

            # Load autoencoder
            autoencoder_path = os.path.join(latest_folder, 'autoencoder.h5')
            print(f"Loading autoencoder from: {autoencoder_path}")
            self.autoencoder = keras.models.load_model(autoencoder_path)

            # Load threshold
            threshold_path = os.path.join(latest_folder, 'threshold.json')
            print(f"Loading threshold from: {threshold_path}")
            with open(threshold_path, "r") as f:
                threshold_data = json.load(f)
                self.threshold = threshold_data["threshold"]

        except Exception as e:
            print(f"Error during initialization: {str(e)}")
            self.scaler = None
            self.threshold = None
            self.autoencoder = None

    def get_components(self):
        if self.scaler is None or self.threshold is None or self.autoencoder is None:
            return None
        
        return {
            "scaler": self.scaler,
            "threshold": self.threshold,
            "autoencoder": self.autoencoder
        }
    
class Agent(BaseModel):
    id: Union[str, List[str]]

class NormalFilterHids(BaseModel):
    agent: Agent

class PortRange(BaseModel):
    from_: int
    to: int

class EndpointConfig(BaseModel):
    ip: str
    port: PortRange

class NormalFilterNids(BaseModel):
    source: EndpointConfig
    destination: EndpointConfig

class TrainRequestHids(BaseModel):
    normal_filters: List[NormalFilterHids]

class TrainRequestNids(BaseModel):
    normal_filters: List[NormalFilterNids]

os_auth = (config.NIDS_CONFIG["user"], config.NIDS_CONFIG["password"])
os_client = OpenSearch(
    hosts=[{'host': config.NIDS_CONFIG["host"], 'port': config.NIDS_CONFIG["port"]}],
    http_compress=True,  # enables gzip compression for request bodies
    http_auth=os_auth,
    use_ssl=True,
    verify_certs=False,
    ssl_show_warn=False,
    timeout=1000
)
@app.get("/")
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.on_event("startup")
async def on_startup():
    initialize_encoders()

@app.post("/save_settings")
async def save_settings(request: Request):
    # try:
    #     form_data = await request.form()
    #     settings = {
    #         "COLUMNS_TO_USE": form_data['columns'].split(','),
    #         "RELATIVE_FROM": int(datetime.strptime(form_data['relative_from'], '%Y-%m-%dT%H:%M').timestamp() * 1000),
    #         "RELATIVE_TO": int(datetime.strptime(form_data['relative_to'], '%Y-%m-%dT%H:%M').timestamp() * 1000),
    #         "epochs": int(form_data['epochs']),
    #         "batch_size": int(form_data['batch_size'])
    #     }

        return RedirectResponse(url="/", status_code=303)
    
    # except Exception as e:
    #     raise HTTPException(status_code=400, detail=str(e))

@app.get("/testing")
async def testing(request: Request):
    return templates.TemplateResponse("testing.html", {"request": request})

@app.post("/train/hids")
async def train(request: TrainRequestHids):
    print("training process start")
    normal_filters = request.normal_filters

    query = create_query_hids({"normal_filters": [filter.dict() for filter in normal_filters]})
    print(query)
    df = functions.get_opensearch_data(config.HIDS_CONFIG, query, config.COLUMNS_TO_USE_HIDS)
    print(df)

    # Check encoder_wazuh folder
    encoder_path = hids_encoder_base_path
    
    # First check if folder exists, if not create it
    if not os.path.exists(encoder_path):
        os.makedirs(encoder_path)
        print("Created encoder_wazuh folder")
        print("Initial training started")
        model, history, threshold = autoencoder_system_hids.train(df)
    else:
        # Check if folder has any contents (looking for model files)
        folder_contents = os.listdir(encoder_path)
        if not folder_contents:  # folder is empty
            print("encoder_wazuh folder is empty")
            print("Initial training started")
            model, history, threshold = autoencoder_system_hids.train(df)
        else:
            # Check if any subfolder contains model files
            has_model = False
            for item in folder_contents:
                subfolder_path = os.path.join(encoder_path, item)
                if os.path.isdir(subfolder_path):
                    # Check for model files in subfolder
                    if os.path.exists(os.path.join(subfolder_path, 'autoencoder.h5')):
                        has_model = True
                        break
            
            if has_model:
                print("Found existing model")
                print("Retraining started")
                model, history, threshold = autoencoder_system_hids.retrain(df)
            else:
                print("No valid model found in encoder_wazuh folder")
                print("Initial training started")
                model, history, threshold = autoencoder_system_hids.train(df)

    initialize_encoders()

    return {
        "message": "Training completed",
        "folder_status": "Model saved in encoder_wazuh folder"
    }

@app.post("/train/nids")
async def train(request: dict):
    global nids_encoder
    print(request)
    print("training process start")
    normal_filters = request["normal_filters"]
    
    nids_encoder = None

    query = create_query_nids(normal_filters)
    print(query)
    df = functions.get_opensearch_data(config.NIDS_CONFIG, query, config.COLUMNS_TO_USE)
    print(df)

    # Check encoder folder
    encoder_path = nids_encoder_base_path
    
    # First check if folder exists, if not create it
    if not os.path.exists(encoder_path):
        os.makedirs(encoder_path)
        print("Created encoder folder")
        print("Initial training started")
        model, history, threshold = autoencoder_system_nids.train(df)
    else:
        # Check if folder has any contents (looking for model files)
        folder_contents = os.listdir(encoder_path)
        if not folder_contents:  # folder is empty
            print("encoder folder is empty")
            print("Initial training started")
            model, history, threshold = autoencoder_system_nids.train(df)
        else:
            # Check if any subfolder contains model files
            has_model = False
            for item in folder_contents:
                subfolder_path = os.path.join(encoder_path, item)
                if os.path.isdir(subfolder_path):
                    # Check for model files in subfolder
                    if os.path.exists(os.path.join(subfolder_path, 'autoencoder.h5')):
                        has_model = True
                        break
            
            if has_model:
                print("Found existing model")
                print("Retraining started")
                model, history, threshold = autoencoder_system_nids.retrain(df)
            else:
                print("No valid model found in encoder folder")
                print("Initial training started")
                model, history, threshold = autoencoder_system_nids.train(df)

    initialize_encoders()

    return {
        "message": "Training completed",
        "folder_status": "Model saved in encoder folder"
    }

@app.post("/webhook/nids")
async def webhook_receiver(request: dict):
    print(request)
    data = request 
    if not data:
        return JSONResponse(content = {'message': 'No JSON data received'}, status_code = 400)
    # Initialize the encoder
    encoder = EncoderInitializer("nids")

    # Access individual components
    nids_scaler = encoder.scaler
    nids_threshold = encoder.threshold
    nids_autoencoder = encoder.autoencoder

    # Send data to WebSocket server

    with open(config.NIDS_TRAIN_RAW_DATA, "a") as f:
        json.dump(data, f)
        f.write('\n')
        
    
    # if hasattr(data, 'message'):
    #     print(data)
    if "message" in data:
        print(data["message"])
        if data["message"] == "training_completed.":
            print("Reinitialize models.")
            #global nids_scaler, nids_threshold, nids_autoencoder
            #nids_scaler, nids_threshold, nids_autoencoder = init("nids") 
            return JSONResponse(content = {'status': 'Reinitializing models.'}, status_code = 200)
        
    try:
        # Normalize the data\
        # send_message_in_background(json.dumps(data))

        df = pd.json_normalize(data)
        # df = df.fillna('0')

        if set(config.COLUMNS_TO_USE).issubset(df.columns):
            print("kolumny ok")
        else:
            return JSONResponse(content = {'status': 'Data not meet requirements'},status_code = 400)

        # Remove any list brackets or quotes from the data

        for col in df.columns:
            df[col] = df[col].apply(lambda x: str(x).replace('[', '').replace(']', '').replace("'", ''))


        header = not os.path.exists(config.NIDS_TRAIN_DATA)
        df.to_csv(config.NIDS_TRAIN_DATA, mode='a', columns=config.COLUMNS_TO_USE, header=header, index=False)

        processed, processed_original = functions.preprocess(df, config.COLUMNS_TO_USE)
        print(processed_original)
        print(processed)

        if not nids_autoencoder or not nids_scaler or not nids_threshold:
            print('Anomalia wykryta')
            data['mse'] = 0
            data['threshold'] = 0
            output = json.dumps(data)
            send_to_webhook(data)
            print(output)
        
            response = JSONResponse(content={'status': 'Data sent'}, status_code = 200)
            return response

        # Scale the data
        test_data_scaled = nids_scaler.transform(processed)
        
        # Detect anomalies
        mse, anomalies = functions.detect_anomalies(nids_autoencoder, test_data_scaled, nids_threshold)
        
        # Print results
        if anomalies:
            print('Anomalia wykryta')
            data['mse'] = mse[0]
            data['threshold'] = nids_threshold
            output = json.dumps(data)
            send_to_webhook(data)
            print(output)

        response = JSONResponse(content = {'status': 'Data sent'}, status_code = 200)
        return response
    
    except Exception as e:
        print(f"Error processing data: {e}")
        return JSONResponse(content = {'message': f'Error processing data: {e}'},status_code = 500)

@app.post("/webhook/hids")
async def webhook_receiver(request:dict):
    # config = Config()
    print(config)
    try:
        data = request["all_fields"]
        if not data:
            return JSONResponse(content = {'message': 'No JSON data received'}, status_code = 400)
        
        # Initialize the encoder
        encoder = EncoderInitializer("hids")

        # Access individual components
        hids_scaler = encoder.scaler
        hids_threshold = encoder.threshold
        hids_autoencoder = encoder.autoencoder


        data['mse'] = 0
        data['threshold'] = 0

        with open(config.HIDS_TRAIN_RAW_DATA, "a") as f:
            json.dump(data, f)
            f.write('\n')
        # output = json.dumps(data)
        # send_to_webhook(data, "hids")
        # print(output)
        if "message" in data:
            print(data["message"])
            if data["message"] == "training_completed.":
                print("Reinitialize models.")
                #global hids_scaler, hids_threshold, hids_autoencoder
                #hids_scaler, hids_threshold, hids_autoencoder = init("hids") 
                return JSONResponse(content = {'status': 'Reinitializing models.'}, status_code = 200)

        df = pd.json_normalize(data)

        if set(config.COLUMNS_TO_USE_HIDS).issubset(df.columns):
            print("kolumny ok")
        else:
            return JSONResponse(content = {'status': 'Data not meet requirements'},status_code = 400)

        for col in df.columns:
            df[col] = df[col].apply(lambda x: str(x).replace('[', '').replace(']', '').replace("'", ''))

        header = not os.path.exists(config.HIDS_TRAIN_DATA)
        df.to_csv(config.HIDS_TRAIN_DATA, mode='a', columns=config.COLUMNS_TO_USE_HIDS, header=header, index=False)

        processed, processed_original = functions.preprocess(df, config.COLUMNS_TO_USE_HIDS)
        print(processed_original)
        print(processed)

        if not hids_autoencoder or not hids_scaler or not hids_threshold:
            print('Anomalia wykryta')
            data['mse'] = 0
            data['threshold'] = 0
            output = json.dumps(data)
            send_to_webhook(data)
            print(output)
            response = JSONResponse(content={'status': 'Data sent'}, status_code = 200)
            return response
        
        test_data_scaled = hids_scaler.transform(processed)

        mse, anomalies = functions.detect_anomalies(hids_autoencoder, test_data_scaled, hids_threshold)
        
        if anomalies:
            print('Anomalia wykryta')
            data['mse'] = mse[0]
            data['threshold'] = hids_threshold
            output = json.dumps(data)
            send_to_webhook(data)
            print(output)

        response = JSONResponse(content = {'status': 'Data sent'}, status_code = 200)
        return response
    except Exception as e:
        print(f"Error processing data: {e}")
        return JSONResponse(content = {'message': f'Error processing data: {e}'},status_code = 500)

@app.post("/processing")
async def processing_logs(request: Request):
    try:
        data = await request.json()
        nids_events = [item for item in data if item.get("event", {}).get("source") == "nids"]
        hids_events = [item for item in data if item.get("event", {}).get("source") == "hids"]
        
        if nids_events:
            print("nids events: ", len(nids_events))

            df = pd.json_normalize(nids_events)
            columns_to_use = config.COLUMNS_TO_USE
            processed, processed_original = functions.preprocess(df, columns_to_use)

            encoder = EncoderInitializer("nids")
            scaler = encoder.scaler
            threshold = encoder.threshold
            autoencoder = encoder.autoencoder

            test_data_scaled = scaler.transform(processed)
            mse, anomalies = functions.detect_anomalies(autoencoder, test_data_scaled, threshold)

            os_actions = []
            current_date = datetime.now()
            index_formated_date = current_date.strftime("%Y.%m.%d")
            nids_index = config.NIDS_CONFIG["index"]
            index_name= f"{nids_index}-{index_formated_date}"
            for i, item in enumerate(nids_events):
                #print(anomalies[i])
                item.setdefault('anomaly_detection', {}).setdefault('is_anomaly', bool(anomalies[i]))
                item.setdefault('anomaly_detection', {}).setdefault('mse', float(mse[i]))
                item.setdefault('anomaly_detection', {}).setdefault('threshold', float(threshold))
                scoring = 0
                if mse[i] > 0:
                    scoring = (mse[i] - threshold) / mse[i] * 100
                
                item.setdefault('anomaly_detection', {}).setdefault('scoring', float(scoring))
                id_formated_date = current_date.strftime("%y%m%d")
                event_hash=item["event"]["hash"]
                new_document_id = f"{id_formated_date}-{event_hash}"

                action = {
                    "_index": index_name,
                    "_id": new_document_id,
                    "_source": item
                }


                os_actions.append(action)
            
            response = helpers.bulk(os_client, os_actions, max_retries=3)
            print(response)
            send_to_webhook(os_actions)
            #print(nids_events[0]['anomaly_detection'])

        if hids_events:
            print("hids events: ", len(hids_events))
            # print(hids_events[0])
            df = pd.json_normalize(hids_events)
            columns_to_use = config.COLUMNS_TO_USE_HIDS
            processed, processed_original = functions.preprocess(df, columns_to_use)

            encoder = EncoderInitializer("hids")
            scaler = encoder.scaler
            threshold = encoder.threshold
            autoencoder = encoder.autoencoder

            test_data_scaled = scaler.transform(processed)
            mse, anomalies = functions.detect_anomalies(autoencoder, test_data_scaled, threshold)

            os_actions = []
            current_date = datetime.now()
            index_formated_date = current_date.strftime("%Y.%m.%d")
            hids_index = config.HIDS_CONFIG["index"]
            index_name= f"{hids_index}-{index_formated_date}"
            for i, item in enumerate(hids_events):
                #print(anomalies[i])
                item.setdefault('anomaly_detection', {}).setdefault('is_anomaly', bool(anomalies[i]))
                item.setdefault('anomaly_detection', {}).setdefault('mse', float(mse[i]))
                item.setdefault('anomaly_detection', {}).setdefault('threshold', float(threshold))
                scoring = 0
                if mse[i] > 0:
                    scoring = (mse[i] - threshold) / mse[i] * 100
                
                item.setdefault('anomaly_detection', {}).setdefault('scoring', float(scoring))

                new_document_id = item["id"]

                action = {
                    "_index": index_name,
                    "_id": new_document_id,
                    "_source": item
                }

                os_actions.append(action)
            
            response = helpers.bulk(os_client, os_actions, max_retries=3)
            print(response)
            send_to_webhook(os_actions)

    except Exception as e:
        print(f"Error processing data: {e}")
        return JSONResponse(content = {'message': f'Error processing data: {e}'},status_code = 500)

@app.get("/check_anomalies")
async def check_anomalies(request: Request):
    with encoder_lock:
        try:
            # Parse request parameters
            params = await request.json()
            event_source = params.get("event_source")
            event_data = params.get("data")

            print(f'event_source: {event_source}')

            # Determine which models to use based on event source
            if event_source == "nids":
                encoder = EncoderInitializer("nids")
                scaler = encoder.scaler
                threshold = encoder.threshold
                autoencoder = encoder.autoencoder
                columns_to_use = config.COLUMNS_TO_USE
            elif event_source == "hids":
                encoder = EncoderInitializer("hids")
                scaler = encoder.scaler
                threshold = encoder.threshold
                autoencoder = encoder.autoencoder
                columns_to_use = config.COLUMNS_TO_USE_HIDS
            else:
                return JSONResponse(
                    content={'message': 'Invalid event source'},
                    status_code=400
                )
                

            # Convert event data to DataFrame
            df = pd.json_normalize(event_data)

            # Preprocess the data
            processed, processed_original = functions.preprocess(df, columns_to_use)

            # Check if models are initialized
            if scaler is None or threshold is None or autoencoder is None:
                return JSONResponse(
                    content={
                        'scaler': None,
                        'threshold': None,
                        'autoencoder': None,
                        'message': 'Encoder components are not initialized'
                    },
                    status_code=200
                )

            # Scale the data
            test_data_scaled = scaler.transform(processed)

            # Detect anomalies
            mse, anomalies = functions.detect_anomalies(autoencoder, test_data_scaled, threshold)

            # Calculate scoring
            if mse[0] > 0:
                scoring = (mse[0] - threshold) / mse[0] * 100
            else:
                scoring = 0

            response_data = {
                'mse': mse[0],
                'threshold': threshold,
                'scoring': scoring,
                'is_anomaly': bool(anomalies)
            }

            print(response_data)
            return JSONResponse(
                content=response_data,
                status_code=200
            )

        except Exception as e:
            print(f"Error processing data: {e}")
            return JSONResponse(
                content={'message': f'Error processing data: {e}'},
                status_code=500
            )

    
def create_query_hids(params: Dict[str, Any]) -> Dict[str, Any]:
    if "normal_filters" in params:
        should_arr = []
        for nf in params["normal_filters"]:
            # Check if agent id is a list/array
            if isinstance(nf["agent"]["id"], (list, tuple)):
                # Create a terms query for multiple IDs
                query = {
                    "bool": {
                        "must": [
                            {
                                "terms": {
                                    "agent.id": nf["agent"]["id"]
                                }
                            }
                        ]
                    }
                }
            elif nf["agent"].get("id") == "*" or not nf["agent"].get("id"):
                # Handle wildcard or empty case - match all agents
                query = {
                    "bool": {
                        "must": [
                            {
                                "exists": {
                                    "field": "agent.id"
                                }
                            }
                        ]
                    }
                }
            else:
                # Handle single ID case (original behavior)
                query = {
                    "bool": {
                        "must": [
                            {
                                "match_phrase": {
                                    "agent.id": nf["agent"]["id"]
                                }
                            }
                        ]
                    }
                }
            should_arr.append(query)
    else:
        should_arr = [{"match_all": {}}]
    
    return {
        "size": 10000,
        "query": {
            "bool": {
                "filter": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": "now-1h/h",
                                        "lt": "now",
                                    }
                                },
                            }
                        ],
                        "should": should_arr,
                        "minimum_should_match": 1
                    }
                }
            }
        },
        "sort": [
            {
                "@timestamp": {
                    "order": "asc"
                }
            }
        ]
    }

def create_query_nids(params: dict):
    if "normal_filters" in params:
        should_arr = []
        for nf in params["normal_filters"]:
            query = {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "source.ip": nf["source"]["ip"]
                            }
                        },
                        {
                            "range": {
                                "source.port": {
                                    "gte": nf["source"]["port"]["from"],
                                    "lte": nf["source"]["port"]["to"],
                                }
                            },
                        },
                        {
                            "range": {
                                "destination.port": {
                                    "gte": nf["destination"]["port"]["from"],
                                    "lte": nf["destination"]["port"]["to"],
                                }
                            },
                        },
                        {
                            "match_phrase": {
                                "destination.ip": nf["destination"]["ip"]
                            }
                        }
                    ]
                }
            }
            should_arr.append(query)
    else:
        should_arr = [{"match_all": {}}]
    
    return {
        "size": 10000,
        "query": {
            "bool": {
                "filter": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    "@timestamp": {
                                        "gte": "now-1h/h",
                                        "lt": "now",
                                    }
                                },
                            }
                        ],
                        "should": should_arr,
                        "minimum_should_match": 1
                    }
                }
            }
        },
        "sort": [
            {
                "@timestamp": {
                    "order": "asc"
                }
            }
        ]
    }

def get_latest_folder(base_path):
    print(f"Searching for folders in: {base_path}")
    if not os.path.exists(base_path):
        raise ValueError(f"The base path does not exist: {base_path}")
    
    folders = [f for f in os.listdir(base_path) if os.path.isdir(os.path.join(base_path, f))]
    print(f"Found folders: {folders}")
    
    date_folders = []
    for folder in folders:
        try:
            datetime.strptime(folder, '%Y-%m-%d %H:%M')
            date_folders.append(folder)
        except ValueError:
            print(f"Skipping non-date folder: {folder}")
    
    print(f"Valid date folders: {date_folders}")
    
    if not date_folders:
        raise ValueError(f"No valid date folders found in {base_path}")
    
    latest_folder = max(date_folders, key=lambda x: datetime.strptime(x, '%Y-%m-%d %H:%M'))
    return os.path.join(base_path, latest_folder)

uri = 'https://scp-anomalies.sec4b.corp/api/live-alerts/webhook/lckc_scp_test'
# ws = websocket.WebSocket()
def send_to_webhook(msg):
    # uri = uri + "?source=" + source
    r = requests.post(uri, json=msg, verify=False)
    # print(r)

def initialize_encoders():
    global nids_encoder, hids_encoder
    try:
        print("Initializing encoders...")
        nids_encoder = EncoderInitializer("nids")
        hids_encoder = EncoderInitializer("hids")
        print("Encoders initialized successfully.")
    except Exception as e:
        print(f"Error initializing encoders: {e}")
        nids_encoder = None
        hids_encoder = None
