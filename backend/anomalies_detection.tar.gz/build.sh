#!/bin/bash
docker build -t anomalies_detection:1.0.0-dev .